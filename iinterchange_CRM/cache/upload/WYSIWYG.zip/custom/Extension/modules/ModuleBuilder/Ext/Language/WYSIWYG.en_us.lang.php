<?php
// NOTE => Field Type
$mod_strings['fieldTypes']['wysiwyg']='WYSIWYG';
?>
